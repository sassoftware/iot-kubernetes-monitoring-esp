# Security Considerations for Logging

The content in this file has been replaced by 
[Limiting Access to Logs](Limiting_Access_to_Logs.md).