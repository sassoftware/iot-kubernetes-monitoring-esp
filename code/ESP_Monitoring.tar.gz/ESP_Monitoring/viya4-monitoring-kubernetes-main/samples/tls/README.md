# TLS-Enabled Monitoring and Logging

This sample demonstrates how to deploy monitoring and logging with
Transport Layer Security (TLS) enabled for both ingress (north-south) and in-cluster (east-west)
traffic.

## Installation

For instructions, see the README files below:

* [Monitoring](monitoring.md)
* [Logging](logging.md)
