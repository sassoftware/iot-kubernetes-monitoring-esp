
># This document has been superseded by [ARTIFACT_INVENTORY.md](ARTIFACT_INVENTORY.md).  Refer to that file for the list of container images used by SAS Viya Monitoring for Kubernetes.
