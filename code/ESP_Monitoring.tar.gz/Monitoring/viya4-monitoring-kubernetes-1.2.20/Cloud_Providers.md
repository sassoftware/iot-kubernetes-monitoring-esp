# Cloud Providers

See [Monitoring and Logging on Cloud-Provider Platforms](https://documentation.sas.com/?cdcId=obsrvcdc&cdcVersion=default&docsetId=obsrvdply&docsetTarget=n0lzjee544jib9n1dj4wc0fhuc36.htm) in the SAS Viya Monitoring for Kubernetes Help Center.