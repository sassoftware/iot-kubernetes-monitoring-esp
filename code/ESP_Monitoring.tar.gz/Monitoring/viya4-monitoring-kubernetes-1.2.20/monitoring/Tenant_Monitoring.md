# Deploying Monitoring for Tenants 

>**Important:** The features formerly documented here were deprecated in release 1.2.16 and, subsequently, removed in release 1.2.17.

