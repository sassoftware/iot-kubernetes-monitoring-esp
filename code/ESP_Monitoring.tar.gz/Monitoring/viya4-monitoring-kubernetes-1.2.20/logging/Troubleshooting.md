# Troubleshooting

See [Troubleshooting](https://documentation.sas.com/?cdcId=obsrvcdc&cdcVersion=default&docsetId=obsrvdply&docsetTarget=p1f3c5so49c0fyn1hrdplosqc6l1.htm) in the SAS Viya Monitoring for Kubernetes Help Center.