# SAS Viya Log-monitoring on Red Hat OpenShift

See [Monitoring on Red Hat OpenShift](https://documentation.sas.com/?cdcId=obsrvcdc&cdcVersion=default&docsetId=obsrvdply&docsetTarget=n1o8xyp2vatupan1nhgknbzhp7tm.htm) in the SAS Viya Monitoring for Kubernetes Help Center.