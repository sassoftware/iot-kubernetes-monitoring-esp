* 10_search_k8s_events.ndjson
* 10_search_update_checker.ndjson
* 20_vis_k8s_warn_reason.ndjson
* 20_viz_k8s_dash_header.ndjson
* 20_viz_k8s_warn_src.ndjson
* 20_viz_update_checker.ndjson
* 30_dash_k8s_events.ndjson
* 30_dash_update_checker.ndjson
