# Implementing Access Limitations for Logging for Tenants

See [Limit Access in a Multi-Tenant Environment](https://documentation.sas.com/?cdcId=obsrvcdc&cdcVersion=default&docsetId=obsrvdply&docsetTarget=n12rumatqso1ivn1v4qg4932ajn2.htm) in the SAS Viya Monitoring for Kubernetes Help Center.