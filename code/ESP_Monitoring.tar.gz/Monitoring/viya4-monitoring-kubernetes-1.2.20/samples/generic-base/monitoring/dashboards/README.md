# User-Provided Dashboards

You can use the `$USER_DIR/monitoring/dashboards` directory to supply
a set of additional Grafana dashboards to deploy with the monitoring
components. See [Adding More Grafana Dashboards](https://documentation.sas.com/?cdcId=obsrvcdc&cdcVersion=default&docsetId=obsrvdply&docsetTarget=n1sg9bc44ow616n1sw7l3dlsbmgz.htm) for details.
