# Enabling TLS for SAS Viya Monitoring for Kubernetes

As of release 1.2.15 (18JUL23), the components of SAS Viya Monitoring for Kubernetes 
are deployed with TLS *enabled by default*.  Therefore, no additional steps are required and this sample is no longer necessary.
 
For information about how to configure access via Kubernetes Ingress to the SAS Viya 
Monitoring for Kubernetes web applications, see the [Ingress sample](../ingress/README.md).

>***IMPORTANT NOTE: This sample is deprecated.***

This sample will be removed at some point in the future.