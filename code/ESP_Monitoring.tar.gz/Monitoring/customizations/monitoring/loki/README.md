# This folder contains manifests for the configmap,
# daemonset, and nodeport for Promtail. 
#
# NOTE: Do not change the file names!
