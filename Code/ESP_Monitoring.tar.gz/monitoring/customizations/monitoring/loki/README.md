# This folder contains manifests for the configmap,
# daemonset, and nodeport for Promtail. The sample
# file is used as a template to generate the config
# map.
# NOTE: Do not change names or delete the files!
